<?php
include_once('connects.php');

$usermail = $_GET['usermail'];
$newpass = $_GET['newpass'];

$result = mysqli_query($con, "UPDATE user_table SET pword='$newpass' WHERE usermail = '$usermail'");

if ($result) {
    echo "Welcome back!";
} else {
    echo "Failed";	
}

mysqli_close($con);
?>