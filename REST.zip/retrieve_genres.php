<?php

include_once('connects.php');

// Retrieve the most common genre and its vote count from the suggest_table
$query = "SELECT genre, COUNT(*) AS genre_count FROM suggest_table GROUP BY genre ORDER BY genre_count DESC LIMIT 1";
$result = mysqli_query($con, $query);

if ($result) {
    if ($row = mysqli_fetch_assoc($result)) {
        $genre = $row['genre'];
        $count = $row['genre_count'];
        echo "$genre with $count votes";
    } else {
        echo "No genres found";
    }
} else {
    echo "Error retrieving genres";
}

?>
