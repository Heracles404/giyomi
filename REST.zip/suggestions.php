<?php

include_once('connects.php');
$genre = $_GET['genre'];
$suggestBName = $_GET['suggestBName'];

$result = mysqli_query($con, "INSERT INTO suggest_table (genre, suggestBName) VALUES ('$genre', '$suggestBName')");

if ($result) {
    echo "Suggestion sent";
} else {
    echo "Failed to send suggestion";
}

?>
