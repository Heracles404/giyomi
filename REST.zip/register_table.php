<?php

include_once('connects.php');

$uname = $_GET['uname'];
$pword = $_GET['pword'];
$usermail = $_GET['usermail'];


$query = "INSERT INTO user_table (uname, pword, usermail) VALUES ('$uname', '$pword', '$usermail')";

if (mysqli_query($con, $query)) {
    echo "Data inserted successfully";
} else {
    echo "Error inserting data: " . mysqli_error($con);
}

mysqli_close($con);
?>
