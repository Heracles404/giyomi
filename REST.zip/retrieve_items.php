<?php
// Retrieve the items and their details from the pre_order_table
include_once('connects.php');

$username = $_GET['username'];

$query = "SELECT bookName, refnum, paymentmode, price, phoneNumber FROM pre_order_table WHERE username='$username'";
$result = mysqli_query($con, $query);

if ($result) {
    $data = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $itemData = array(
            'bookName' => $row['bookName'],
            'refnum' => $row['refnum'],
            'paymentmode' => $row['paymentmode'],
            'price' => $row['price'],
            'phoneNumber' => $row['phoneNumber']
        );
        $data[] = $itemData;
    }
    echo json_encode($data);
} else {
    echo "Query failed";
}

mysqli_close($con);
?>
