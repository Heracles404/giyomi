<?php
include_once('connects.php');

$username = $_GET['username'];
$bookName = $_GET['bookName'];
$paymentmode = $_GET['paymentmode'];
$referenceNumber = $_GET['referenceNumber'];
$phoneNumber = $_GET['phoneNumber'];

$query = "INSERT INTO pre_order_table(username, price, bookName, refnum, paymentmode, phoneNumber) VALUES('$username', '800', '$bookName', '$referenceNumber', '$paymentmode', '$phoneNumber')";

if (mysqli_query($con, $query)) {
    echo "Purchase Successful";
} else {
    echo "Something went wrong. Try Again.";
}

mysqli_close($con);
?>